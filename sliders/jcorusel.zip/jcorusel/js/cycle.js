$('.overview1').cycle({
	timeout:0,
	speed : 300,
	fx:     'scrollHorz', 
    prev:   '.prev1', 
    next:   '.next1'
	});
$('.overview2').cycle({
	timeout:0,
	speed : 300,
	fx:     'scrollHorz', 
    prev:   '.prev2', 
    next:   '.next2'
	});$('.overview3').cycle({
	timeout:0,
	speed : 300,
	fx:     'scrollHorz', 
    prev:   '.prev3', 
    next:   '.next3'
	});$('.overview4').cycle({
	timeout:0,
	speed : 300,
	fx:     'scrollHorz', 
    prev:   '.prev4', 
    next:   '.next4'
	});$('.overview5').cycle({
	timeout:0,
	speed : 300,
	fx:     'scrollHorz', 
    prev:   '.prev5', 
    next:   '.next5'
	});$('.overview6').cycle({
	timeout:0,
	speed : 300,
	fx:     'scrollHorz', 
    prev:   '.prev6', 
    next:   '.next6'
	});	$('.overview7').cycle({
	timeout:0,
	speed : 300,
	fx:     'scrollHorz', 
    prev:   '.prev7', 
    next:   '.next7'
	});