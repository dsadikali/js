// jQuery Custom Dropdown.
var wrapper_counter=0;

	jQuery.fn.customDropdown = function( objOptions ){
		
		var obj = jQuery.extend({},jQuery.fn.customDropdown.Default,objOptions);
			
			$(obj.mainSelector).each(function(){
				$(this).append("<dl><dt><div></div></dt><dd></dd></dl>");
				$(this).find(' dl dd').append('<ul class="cf" />');
				var ele = $(this);
				$(this).find('option').each(function(){
				if($(this).text()==ele.find('select').val()){
						$(this).closest(obj.mainSelector).find('dl dt div').text(this.text)
						$(this).closest(obj.mainSelector).find('dl ul').append('<li class="active">' + this.text +'</li>')
						$(this).closest(obj.mainSelector).find('li.active').hide();
						}
			
				else{
						$(this).closest(obj.mainSelector).find('dl dd ul').append("<li>" + this.text +"</li>")
					}
			
					})		
			});
			
			

		
				$(obj.mainSelector+' dt').click(function(){
					$(obj.mainSelector).removeClass('focused');
					$(this).closest(obj.mainSelector).addClass('focused');
					$(obj.mainSelector+' dd').each(function(){
						if(!$(this).closest(obj.mainSelector).hasClass('focused'))
							$(this).hide();
					});
					$(this).closest(obj.mainSelector).find('dd').toggle();					
					$(this).closest(obj.mainSelector).find('dd li').show();					
					$(this).closest(obj.mainSelector).find('li.active').hide();					
					})	
				
				$(obj.mainSelector+' li').click(function(){
					$(this).closest(obj.mainSelector).find('dd').hide();
					$(this).closest(obj.mainSelector).find('li').removeClass('active')
					$(this).addClass('active')
					var txt = $(this).text();
					$(this).closest(obj.mainSelector).find('dt div').text($(this).text())
					$(this).closest(obj.mainSelector).find('option').removeAttr('selected')
					$(this).closest(obj.mainSelector).find('select').val($(this).html())
					$(this).closest(obj.mainSelector).find('option').each(function(){
					if($(this).text()== txt)
							$(this).attr('selected',true);
					});
					
				})	
		
				$(obj.mainSelector+' select').hide()
				$(obj.mainSelector+' dd').hide()		
		
		return( this );
		
		}


/*=========================customDropdown options============================*/

	// Define the jQuery method's default properties.

	jQuery.fn.customDropdown.Default = 
		{
			mainSelector:'.customDropdown select'
		}
$(function(){		
	$('body').customDropdown({
		mainSelector:'.customDropdown'
	});	
	
	$(document).mouseup(function(e) {
		if($(e.target).parent(".customDropdown dt").length==0){
				$(".customDropdown").find('dd').hide();
			}
			});		
	
})



